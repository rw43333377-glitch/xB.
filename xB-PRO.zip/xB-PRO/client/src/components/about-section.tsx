import { Edit, Settings, Users, TrendingUp } from "lucide-react";

export default function AboutSection() {
  const services = [
    {
      icon: Edit,
      title: "Content Creation",
      description:
        "I can ghostwrite detailed insider threads and help expand your presence through Spaces and audience engagement.",
    },
    {
      icon: Settings,
      title: "Versatility",
      description:
        "I'm proactive and adaptable, ready to assist in any area within your scope of work.",
    },
    {
      icon: Users,
      title: "Community Management",
      description:
        "I can build, grow, and manage a Telegram call channel to amplify your trading calls and engage your audience.",
    },
    {
      icon: TrendingUp,
      title: "On-Chain Analysis",
      description:
        "I excel at analyzing blockchain data and can identify promising gems tailored to your trading strategies.",
    },
  ];

  return (
    <section id="about" className="py-20 bg-white dark:bg-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            About Me
          </h2>
          <div className="w-24 h-1 bg-gradient-crypto mx-auto rounded-full"></div>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="bg-gray-50 dark:bg-gray-900 rounded-2xl p-8 sm:p-12 shadow-lg">
            <p className="text-lg text-gray-700 dark:text-gray-300 mb-8 leading-relaxed">
              With your growing visibility, I understand you're likely handling
              more responsibilities, and I'm confident I can help lighten the
              load.
            </p>

            <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-6">
              Here's how I can contribute:
            </h3>

            <div className="grid gap-6 md:grid-cols-2">
              {services.map((service, index) => {
                const IconComponent = service.icon;
                return (
                  <div key={index} className="flex items-start space-x-4">
                    <div className="flex-shrink-0">
                      <div className="w-8 h-8 bg-gradient-crypto rounded-full flex items-center justify-center">
                        <IconComponent className="h-4 w-4 text-white" />
                      </div>
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                        {service.title}
                      </h4>
                      <p className="text-gray-600 dark:text-gray-400">
                        {service.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
