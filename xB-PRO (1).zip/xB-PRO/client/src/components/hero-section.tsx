import { Button } from "@/components/ui/button";
import { Mail } from "lucide-react";
import { FaTwitter } from "react-icons/fa";

export default function HeroSection() {
  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      const offsetTop = element.offsetTop - 80;
      window.scrollTo({
        top: offsetTop,
        behavior: "smooth",
      });
    }
  };

  return (
    <section
      id="hero"
      className="pt-20 pb-16 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 min-h-screen flex items-center"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="mb-8">
            <img
              src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400"
              alt="Mr ✗₿. Profile Picture"
              className="w-32 h-32 sm:w-40 sm:h-40 rounded-full mx-auto shadow-2xl border-4 border-white dark:border-gray-700 object-cover"
            />
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 dark:text-white mb-6">
            Hi, I'm{" "}
            <span className="text-gradient-crypto">Mr ✗₿.</span>
          </h1>

          <p className="text-xl sm:text-2xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto leading-relaxed">
            Helping Web3 projects thrive and succeed together.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              onClick={scrollToContact}
              className="inline-flex items-center px-8 py-4 text-base font-medium rounded-xl text-white bg-gradient-crypto hover:bg-gradient-crypto-reverse transform hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              <Mail className="mr-2 h-5 w-5" />
              Contact Me
            </Button>
            <Button
              variant="outline"
              asChild
              className="inline-flex items-center px-8 py-4 border-2 border-crypto-primary text-base font-medium rounded-xl text-crypto-primary dark:text-crypto-primary hover:bg-crypto-primary hover:text-white transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              <a
                href="https://x.com/Crypt0Danieli?t=GrKyIDPG62-aFg31Ly4YrA&s=09"
                target="_blank"
                rel="noopener noreferrer"
              >
                <FaTwitter className="mr-2 h-5 w-5" />
                Follow on X
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
