import { Button } from "@/components/ui/button";
import { Mail, Send } from "lucide-react";
import { FaTwitter, FaTelegram } from "react-icons/fa";

export default function ContactSection() {

  return (
    <section
      id="contact"
      className="py-20 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Let's Work Together
          </h2>
          <div className="w-24 h-1 bg-gradient-crypto mx-auto rounded-full"></div>
          <p className="text-lg text-gray-600 dark:text-gray-300 mt-6 max-w-2xl mx-auto">
            Ready to take your Web3 project to the next level? Get in touch and
            let's discuss how I can help you succeed.
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="grid gap-8 lg:grid-cols-3">
            {/* Email Contact Card */}
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-crypto rounded-full flex items-center justify-center mx-auto mb-6">
                  <Mail className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  Email Me
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  Send me a message and I'll get back to you within 24 hours.
                </p>
                <Button
                  asChild
                  className="inline-flex items-center px-6 py-3 bg-gradient-crypto text-white font-medium rounded-xl hover:bg-gradient-crypto-reverse transition-all duration-200 transform hover:scale-105"
                >
                  <a href="mailto:rw43333377@gmail.com">
                    <Send className="mr-2 h-4 w-4" />
                    rw43333377@gmail.com
                  </a>
                </Button>
              </div>
            </div>

            {/* Telegram Contact Card */}
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-crypto rounded-full flex items-center justify-center mx-auto mb-6">
                  <FaTelegram className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  Message on Telegram
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  Connect with me instantly for quick discussions and updates.
                </p>
                <Button
                  variant="outline"
                  asChild
                  className="inline-flex items-center px-6 py-3 border-2 border-crypto-primary text-crypto-primary font-medium rounded-xl hover:bg-crypto-primary hover:text-white transition-all duration-200 transform hover:scale-105"
                >
                  <a
                    href="https://t.me/Mr_xB_onX"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <FaTelegram className="mr-2 h-4 w-4" />
                    @Mr_xB_onX
                  </a>
                </Button>
              </div>
            </div>

            {/* Social Media Contact Card */}
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-crypto rounded-full flex items-center justify-center mx-auto mb-6">
                  <FaTwitter className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  Follow on X
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  Stay updated with my latest insights and Web3 content.
                </p>
                <Button
                  variant="outline"
                  asChild
                  className="inline-flex items-center px-6 py-3 border-2 border-crypto-primary text-crypto-primary font-medium rounded-xl hover:bg-crypto-primary hover:text-white transition-all duration-200 transform hover:scale-105"
                >
                  <a
                    href="https://x.com/Crypt0Danieli?t=GrKyIDPG62-aFg31Ly4YrA&s=09"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <FaTwitter className="mr-2 h-4 w-4" />
                    @Crypt0Danieli
                  </a>
                </Button>
              </div>
            </div>
          </div>

          {/* Call to Action */}
          <div className="text-center mt-12">
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 sm:p-12 shadow-lg">
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                Ready to Get Started?
              </h3>
              <p className="text-lg text-gray-600 dark:text-gray-300 mb-8 max-w-2xl mx-auto">
                Let's discuss your project and how my expertise can help you
                achieve your Web3 goals.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  asChild
                  className="inline-flex items-center px-8 py-4 bg-gradient-crypto text-white font-medium rounded-xl hover:bg-gradient-crypto-reverse transition-all duration-200 transform hover:scale-105 shadow-lg"
                >
                  <a href="mailto:rw43333377@gmail.com">
                    <Mail className="mr-2 h-5 w-5" />
                    Send Email
                  </a>
                </Button>
                <Button
                  variant="outline"
                  asChild
                  className="inline-flex items-center px-8 py-4 border-2 border-crypto-primary text-crypto-primary font-medium rounded-xl hover:bg-crypto-primary hover:text-white transition-all duration-200 transform hover:scale-105"
                >
                  <a
                    href="https://t.me/Mr_xB_onX"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <FaTelegram className="mr-2 h-5 w-5" />
                    Message on Telegram
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}