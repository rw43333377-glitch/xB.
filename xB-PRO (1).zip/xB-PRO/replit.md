# Overview

This is a full-stack web application built with React and Express.js that serves as a personal portfolio website for "Mr. xB," a Web3 professional specializing in content creation, community management, and on-chain analysis. The application features a modern, responsive design with a clean landing page showcasing services and contact information.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Routing**: Wouter for lightweight client-side routing
- **UI Framework**: Radix UI components with shadcn/ui for accessible, customizable components
- **Styling**: Tailwind CSS with custom design tokens and dark/light theme support
- **State Management**: React Query (TanStack Query) for server state management
- **Form Handling**: React Hook Form with Zod validation schemas

## Backend Architecture
- **Framework**: Express.js with TypeScript for the REST API server
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Session Management**: PostgreSQL session store with connect-pg-simple
- **Development**: Vite for development server with HMR and error overlay

## Data Storage Solutions
- **Primary Database**: PostgreSQL hosted on Neon for user data and application state
- **ORM**: Drizzle ORM with code-first schema definition and automatic migrations
- **Schema Management**: Shared schema definitions between client and server using Drizzle-Zod
- **Fallback Storage**: In-memory storage implementation for development/testing

## Authentication and Authorization
- **Session-based Authentication**: Using PostgreSQL session store for persistent sessions
- **User Management**: Basic user schema with username/password authentication
- **Storage Interface**: Abstracted storage layer supporting multiple implementations (memory, database)

## Development and Build System
- **Build Tool**: Vite for fast development and optimized production builds
- **Package Manager**: npm with lockfile for consistent dependency management
- **TypeScript**: Strict configuration with path aliases for clean imports
- **Development Server**: Express server with Vite middleware integration for seamless full-stack development

# External Dependencies

## UI and Component Libraries
- **Radix UI**: Complete set of accessible UI primitives (@radix-ui/react-*)
- **shadcn/ui**: Pre-built component library built on Radix UI
- **Lucide React**: Icon library for consistent iconography
- **React Icons**: Additional icon set including social media icons

## Database and ORM
- **Neon Database**: Serverless PostgreSQL database (@neondatabase/serverless)
- **Drizzle ORM**: Type-safe database operations (drizzle-orm, drizzle-kit)
- **Drizzle-Zod**: Schema validation integration between Drizzle and Zod

## Styling and Design
- **Tailwind CSS**: Utility-first CSS framework
- **PostCSS**: CSS processing with Autoprefixer
- **Class Variance Authority**: Type-safe variant management for components
- **clsx**: Conditional className utility

## Development Tools
- **Replit Integration**: Custom Vite plugins for Replit environment (@replit/vite-plugin-*)
- **TypeScript**: Static type checking and enhanced development experience
- **ESBuild**: Fast JavaScript bundler for production builds

## Date and Utility Libraries
- **date-fns**: Date manipulation and formatting
- **nanoid**: Unique ID generation
- **Embla Carousel**: Carousel component functionality